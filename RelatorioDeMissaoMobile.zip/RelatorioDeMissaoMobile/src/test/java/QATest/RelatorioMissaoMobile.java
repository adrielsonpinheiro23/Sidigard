package QATest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;


public class RelatorioMissaoMobile {

    private static AndroidDriver<MobileElement> driver;

    @BeforeAll
    public static void getDriver() {

    DesiredCapabilities desiredCapabilities = new DesiredCapabilities();

    desiredCapabilities.setCapability("platformName", "Android");
    desiredCapabilities.setCapability("platformVersion", "13");
    desiredCapabilities.setCapability("skipDeviceInitialization", true);
    desiredCapabilities.setCapability("skipServerInstallation", true);

        System.out.println("Connecting!");
        try {
            driver = new AndroidDriver<MobileElement>(new URL("http://localhost:4723/wd/hub"), desiredCapabilities);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Connected");
    }

    @AfterEach
    public void HomeBack(){
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.pressKey(new KeyEvent(AndroidKey.HOME));
    }

    @Test
    public void searchGacebook() {

        new TouchAction(driver)
                .press(PointOption.point(532, 1223))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(500)))
                .moveTo(PointOption.point(515, 494))
                .release()
                .perform();

        driver.findElementById("com.sec.android.app.launcher:id/app_search_edit_text").click();
        driver.findElementById("com.samsung.android.app.galaxyfinder:id/edit_search").click();
        driver.findElementById("com.samsung.android.app.galaxyfinder:id/edit_search").sendKeys("Gacebook");
        driver.hideKeyboard();
        String facebook = driver.findElementById("com.samsung.android.app.galaxyfinder:id/app_label").getText();
        String facebookApp = "Facebook";
        assertEquals(facebookApp, facebook);
    }

    @Test
    public void checkGalaxyApps() {

        new TouchAction(driver)
                .press(PointOption.point(532, 1223))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(800)))
                .moveTo(PointOption.point(515, 494))
                .release()
                .perform();

        driver.findElementById("com.sec.android.app.launcher:id/app_search_edit_text").click();
        driver.findElementById("com.samsung.android.app.galaxyfinder:id/edit_search").click();
        driver.findElementById("com.samsung.android.app.galaxyfinder:id/edit_search").sendKeys("Galaxy");
        driver.hideKeyboard();
        List<MobileElement> elementsById = driver.findElementsById("com.samsung.android.app.galaxyfinder:id/app_label");
        driver.findElementsById("com.samsung.android.app.galaxyfinder:id/app_label");

        for (MobileElement element : elementsById) {
            String galaxyApps = "Galaxy";
            assertTrue(element.getText().contains(galaxyApps));
        }
    }

    @Test
    public void searchExistentStory() {

        driver.startActivity(new Activity("com.sec.android.gallery3d", "com.samsung.android.gallery.app.activity.GalleryActivity"));
        driver.findElementByAccessibilityId("Search").click();
        driver.findElementById("com.sec.android.gallery3d:id/search_src_text").sendKeys("Story 1");
        driver.findElementById("com.sec.android.gallery3d:id/search_src_text").click();
        driver.findElementById("com.sec.android.gallery3d:id/auto_complete_title").click();
        driver.findElementById("com.sec.android.gallery3d:id/item_count");
        String element = driver.findElementById("com.sec.android.gallery3d:id/item_count").getText();

        List<MobileElement> elementsbyID = driver.findElementsById("com.sec.android.gallery3d:id/thumbnail");
        System.out.println(elementsbyID.size() + " items");
        String elementsbyIDText = String.valueOf(elementsbyID.size());
        Assertions.assertAll(
                () -> assertTrue(elementsbyID.size() == 5),
                () -> assertEquals(elementsbyIDText + " items", element));
    }

    @Test
    public void searchNonExistentStory() {

        driver.startActivity(new Activity("com.sec.android.gallery3d", "com.samsung.android.gallery.app.activity.GalleryActivity"));
        driver.findElementByAccessibilityId("Search").click();
        driver.findElementById("com.sec.android.gallery3d:id/search_src_text").sendKeys(" Story 2");
        driver.findElementById("com.sec.android.gallery3d:id/search_src_text").click();
        driver.getKeyboard().sendKeys(Keys.ENTER);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        String NonExistentStory = driver.findElementByXPath("//*[@text='No results found']").getText();
        String noResultFound = "Non Existent Story";
        assertFalse(NonExistentStory == noResultFound);
        System.out.println(NonExistentStory);

    }

}